package com.example.rock.demo.model.request;

import lombok.Data;

@Data
public class MemberCreationRequest {
    private String firstName;
    private String LastName;
}
