package com.example.rock.demo.model;

public enum MemberStatus {
    ACTIVE, DEACTIVATED
}